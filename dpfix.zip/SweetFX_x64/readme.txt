  
  Copy all the DLL from this folder to the parent level folder if you want to use SweetFX with 64 bits applications/games