Installation:
- Install DPfix by Durante http://blog.metaclassofnil.com/
- Change enableTextureOverride 0 to 1 in DPfix.ini
- Copy textures to Deadly Premonition The Director's Cut\dpfix\tex_override folder

Map from ba5a3107.dds is made by Whitney Chavis (http://fkinthecoffee.com).
Thank you, Whitney!

All other textures are either made by me or taken from other parts of the game (pistol, envelope, bench, bookshelf).